A sample command-line application providing basic argument parsing with an entrypoint in `bin/`.
